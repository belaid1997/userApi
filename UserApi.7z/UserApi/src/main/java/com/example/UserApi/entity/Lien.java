package com.example.UserApi.entity;

import java.net.URL;

public class Lien {
	
	
	private Long id;
	private URL url;

}
