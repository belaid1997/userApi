package com.example.UserApi.service;

import java.sql.SQLException;
import java.util.*;

public interface RoleService {
	
	
	
	

}
